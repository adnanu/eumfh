<span class="main_data">
<?php include 'form_create_body.php'; ?>
</span> 