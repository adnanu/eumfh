<div class="mail-header">
    <!-- title -->
    <h4 class="mail-title">
        <?php echo get_phrase('messages'); ?>
    </h4>
</div>

<div style="width:100%; text-align:center;padding:100px;color:#aaa;">

    <img src="<?php echo base_url('assets/images/inbox.png'); ?>" width="70">
    <br><br>
    <div>
        <?php echo get_phrase('select_message_to_read');?>
    </div>
</div>