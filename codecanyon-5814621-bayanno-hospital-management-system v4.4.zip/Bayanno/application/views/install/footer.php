<footer class="main"
	style="text-align: center;">
	Download free scripts  <a href="http://daviruzsystems.com" target="_blank" style="text-decoration:underline;">Da-viruz Sysems</a>
</footer>
